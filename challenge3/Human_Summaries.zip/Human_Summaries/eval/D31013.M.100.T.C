Dr. Barnett Slepian, the mainstay of Buffalo's only abortion clinic, was slain as he stood at his kitchen window.
Slepian has been described as a fatalist who stubbornly adhered to doing what he thought right.
The FBI is looking for James Kopp for questioning as a material witness in the slaying.
Kopp has long been identified as a major voice in the anti-abortion movement.
Attorney General Reno will investigate if the slaying is part of a nation-wide plot.
In Canada, authorities are worried that new violence could erupt as Remembrance Day approaches.
Anti-abortion pamphlets have been delivered to a Canadian newspaper, possibly by Kopp.
