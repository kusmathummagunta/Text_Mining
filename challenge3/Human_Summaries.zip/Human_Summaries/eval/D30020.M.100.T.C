Despite economic problems and threats from the Asian Olympic Committee that it would move the games, Thailand was able to meet construction deadlines and open the 13th annual Asian Games to participants from 43 countries.
The games have not been without controversy.
In a surprise move, Saudi Arabia pulled its athletes from the games, probably in reprisal for a jewel theft and the murder of three of its diplomats.
There was speculation that the Saudis would send a ceremonial delegation.
National rivalries also were Apparent in a snooker game between India and Pakistan when an argument Arose following a disputed call.
