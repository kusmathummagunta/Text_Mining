The New York Yankees prevailed in the sixth game of the American League playoffs to win over the Cleveland Indians and advanced to their second World Series play in three years.
In the National League, the San Diego Padres won its series over the Atlanta Braves to ensure its place in the World Series.
Enthusiasm is high on both sides as 650 padres fans shaved their heads in a radio promotion raffle for a ticket to the games.
Yankees Chuck Knoblauch, worried about errors in the playoffs, was greeted with a standing ovation as the first game opened.
Knoblauch, along with teammate Martinez cinched the first game with homerun hits in the 7th inning.
