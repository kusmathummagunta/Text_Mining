As the government continued to press its anti-trust suit against Microsoft, AOL has begun negotiations to purchase Netscape.
Netscape is at the heart of the antitrust suit.
Netscape alleges that Microsoft marketing practices, packaging its Internet Explorer in its operating system denied market opportunities to Netscape.
The AOL deal, a three-way negotiation between AOL, Sun Microsystems and Netscape, would combined three Microsoft rivals.
AOL is counting on the Netscape purchase to allow it to expand its internet Market by helping business operate on the internet in an effort to join Media and technology.
