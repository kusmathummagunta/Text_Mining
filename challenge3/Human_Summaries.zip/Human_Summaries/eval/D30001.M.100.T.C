Cambodia King Norodom Sihanouk praised formation of a coalition of the Countries top two political parties, leaving strongman Hun Sen as Prime Minister and opposition leader Prince Norodom Ranariddh president of the National Assembly.
The announcement comes after months of bitter argument following the failure of any party to attain the required quota to form a government.
Opposition leader Sam Rainey was seeking assurances that he and his party members would not be arrested if they return to Cambodia.
Rainey had been accused by Hun Sen of being behind an assassination attempt against him during massive street demonstrations in September.
