Russia launched the first piece of the international space station into orbit a year after the originally scheduled date.
The launch follows a last minute Russian request to change the orbit of the space station to put it closer to Mir.
This request was set aside.
Two weeks later, the U.S. carried the Unity chamber into orbit.
U.S. astronauts aboard the Endeavor shuttle then joined the Unity chamber to the Russian Zarya control module.
The resulting 7 story structure appeared to be a perfect fit.
In a subsequent second space walk, the astronauts were to install antennas on the Unity chamber as well as to attempt to unjam a Russian antenna.
