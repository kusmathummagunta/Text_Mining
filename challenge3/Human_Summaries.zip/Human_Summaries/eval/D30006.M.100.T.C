The National Basketball Association joined the NHL, the NFL and baseball when it canceled first the preseason games then two weeks of regular season.
In litigation that is complicated by a dispute over the distribution of nearly $2 billion in league income, the main sticking point is the owner's insistence on a salary cap without exceptions.
Top players are avoiding discussion of the Larry Bird exception, which allows a player to secure any amount he wants in resigning with his current team except as it applies to their taxation proposal.
Also pending is an arbiter's decision as to whether players will be paid during the lockout.
